﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp_MOS_test
{
    public partial class cus_update : Form
    {
        SqlConnectionStringBuilder scsb;

        public cus_update()
        {
            InitializeComponent();
        }

        public string strID;
        public string strName;
        public string strGender;
        public string strTel;
        public string strAddress;
        public string strMemo;
        //生日 datetime ??????????????
        public DateTime Birth;

        private void cus_update_Load(object sender, EventArgs e)
        {
            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @".";
            scsb.InitialCatalog = "MOSTest";
            scsb.IntegratedSecurity = true;

            tbu顧客代號.Text = strID;
            tbu姓名.Text = strName;
            cmbu性別.Text = strGender;
            tbu電話.Text = strTel;
            tbu地址.Text = strAddress;
            tbu備註.Text = strMemo;
            //生日 datetime ??????????????
            dtpu生日.Value = Birth;

        }

        private void btn確定_Click(object sender, EventArgs e)
        {
            int intID = 0;
            Int32.TryParse(tbu顧客代號.Text, out intID);

            if (intID > 0)
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "update Customer set 姓名=@NewName, 性別=@NewGender, 生日=@NewBirth, 電話=@NewTel, 地址=@NewAddress, 備註=@NewMemo where 客戶代號=@SearchID";
                SqlCommand cmd = new SqlCommand(strSQL, con);

                cmd.Parameters.AddWithValue("@SearchID", intID);
                cmd.Parameters.AddWithValue("@NewName", tbu姓名.Text);
                cmd.Parameters.AddWithValue("@NewGender", cmbu性別.Text);
                cmd.Parameters.AddWithValue("@NewBirth", (DateTime)dtpu生日.Value);
                cmd.Parameters.AddWithValue("@NewTel", tbu電話.Text);
                cmd.Parameters.AddWithValue("@NewAddress", tbu地址.Text);
                cmd.Parameters.AddWithValue("@NewMemo", tbu備註.Text);

                cmd.ExecuteNonQuery();
                con.Close();
                Close();
            }
            else
            {
                MessageBox.Show("請選擇欲 修改 之產品");
            }
        }

        private void btn取消_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

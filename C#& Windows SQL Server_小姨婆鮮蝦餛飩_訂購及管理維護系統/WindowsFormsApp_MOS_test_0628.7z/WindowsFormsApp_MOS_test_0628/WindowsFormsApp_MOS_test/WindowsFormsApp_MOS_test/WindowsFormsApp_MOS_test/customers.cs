﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp_MOS_test
{
    public partial class customers : Form
    {
        SqlConnectionStringBuilder scsb;

       

        public customers()
        {
            InitializeComponent();
        }
        

        private void customers_Load(object sender, EventArgs e)
        {
            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @".";
            scsb.InitialCatalog = "MOSTest";
            scsb.IntegratedSecurity = true;

            customerList();
        }

        private void btn顧客列表_Click(object sender, EventArgs e)
        {
            lbox顧客姓名.Items.Clear();

            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select * from Customer";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while(reader.Read())
            {
                lbox顧客姓名.Items.Add(reader["姓名"]);
            }
            reader.Close();
            con.Close();

        }

        private void btn清除全部_Click(object sender, EventArgs e)
        {
            tb地址.Text = "";
            tb姓名.Text = "";
            tb電話.Text = "";
            tb顧客代號.Text = "";
            cmb性別.Text = "";
            dtp生日.Value = DateTime.Now;
            lbox顧客姓名.Items.Clear();
            tb備註.Text = "";
            tb查詢結果.Text = "";
        }

        private void btn新增_Click(object sender, EventArgs e)
        {
            cus_create myCusCreate = new cus_create();
            myCusCreate.ShowDialog();

        }

        private void lbox顧客姓名_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strSearchName = lbox顧客姓名.SelectedItem.ToString();

            if (strSearchName != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select * from Customer where 姓名 like @SearchName";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchName", "%" + strSearchName + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    tb顧客代號.Text = string.Format("{0}", reader["客戶代號"]);
                    tb姓名.Text = string.Format("{0}", reader["姓名"]);
                    cmb性別.Text = string.Format("{0}", reader["性別"]);
                    dtp生日.Value = (DateTime)reader["生日"];
                    tb電話.Text = string.Format("{0}", reader["電話"]);
                    tb地址.Text = string.Format("{0}", reader["地址"]);
                    tb備註.Text = string.Format("{0}", reader["備註"]);


                }
                else
                {
                    lbox顧客姓名.Items.Add("查無此顧客");
                    tb地址.Text = "";
                    tb姓名.Text = "";
                    tb電話.Text = "";
                    tb顧客代號.Text = "";
                    cmb性別.Text = "";
                    dtp生日.Value = DateTime.Now;
                    tb備註.Text = "";
                }
                reader.Close();
                con.Close();
            }
 
            else
            {
                MessageBox.Show("請點選 顧客列表 或 查詢");
            }
        }

        private void btn刪除_Click(object sender, EventArgs e)
        {
            int intID = 0;
            Int32.TryParse(tb顧客代號.Text, out intID);

            if (intID > 0)
            {
                DialogResult R;
                R = MessageBox.Show("您確定要 刪除 該筆資料?", "刪除確認", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (R == DialogResult.Yes)
                {
                    SqlConnection con = new SqlConnection(scsb.ToString());
                    con.Open();
                    string strSQL = "delete from Customer where 客戶代號=@SearchID";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.Parameters.AddWithValue("@SearchID", intID);

                    cmd.ExecuteNonQuery();
                    con.Close();

                    tb地址.Text = "";
                    tb姓名.Text = "";
                    tb電話.Text = "";
                    tb顧客代號.Text = "";
                    cmb性別.Text = "";
                    dtp生日.Value = DateTime.Now;
                    lbox顧客姓名.Items.Clear();
                    tb備註.Text = "";
                }
                else
                {

                }
            }
            else
            {
                MessageBox.Show("請選擇欲刪除之 顧客姓名 後,再行刪除");
            }
        }

        private void btn修改_Click(object sender, EventArgs e)
        {
            
            cus_update myC_update = new cus_update();
            

            int intID = 0;
            Int32.TryParse(tb顧客代號.Text, out intID);

            if (intID > 0)
            {
                myC_update.strID = tb顧客代號.Text;
                myC_update.strName = tb姓名.Text;
                myC_update.strGender = cmb性別.Text;
                myC_update.strTel = tb電話.Text;
                myC_update.strAddress = tb地址.Text;
                myC_update.strMemo = tb備註.Text;
                //生日 datetime ??????????????
                myC_update.Birth = (DateTime)dtp生日.Value;

                myC_update.ShowDialog();

                tb地址.Text = "";
                tb姓名.Text = "";
                tb電話.Text = "";
                tb顧客代號.Text = "";
                cmb性別.Text = "";
                dtp生日.Value = DateTime.Now;
                lbox顧客姓名.Items.Clear();
                tb備註.Text = "";

            }
            else
            {
                MessageBox.Show("請選擇欲 修改 之產品");
            }
            



            /*int intID = 0;
            Int32.TryParse(tb顧客代號.Text, out intID);

            if (intID > 0)
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "update Customer set 姓名=@NewName, 性別=@NewGender, 生日=@NewBirth, 電話=@NewTel, 地址=@NewAddress, 備註=@NewMemo where 客戶代號=@SearchID";
                SqlCommand cmd = new SqlCommand(strSQL, con);

                cmd.Parameters.AddWithValue("@SearchID", intID);
                cmd.Parameters.AddWithValue("@NewName", tb姓名.Text);
                cmd.Parameters.AddWithValue("@NewGender", cmb性別.Text);
                cmd.Parameters.AddWithValue("@NewBirth", (DateTime)dtp生日.Value);
                cmd.Parameters.AddWithValue("@NewTel", tb電話.Text);
                cmd.Parameters.AddWithValue("@NewAddress", tb地址.Text);
                cmd.Parameters.AddWithValue("@NewMemo", tb備註.Text);

                cmd.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                MessageBox.Show("請選擇欲 修改 之產品");
            }*/

        }

        private void btn查詢_Click(object sender, EventArgs e)
        {
            lbox顧客姓名.Items.Clear();

            if (tb查詢結果.Text != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select * from Customer where 姓名 like @SearchName";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchName", "%" + tb姓名.Text + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        lbox顧客姓名.Items.Add(reader["姓名"]);
                    }
                }
                else
                {
                    lbox顧客姓名.Items.Add("查無此客戶");
                    tb地址.Text = "";
                    tb姓名.Text = "";
                    tb電話.Text = "";
                    tb顧客代號.Text = "";
                    cmb性別.Text = "";
                    dtp生日.Value = DateTime.Now;
                    tb備註.Text = "";
                }
                reader.Close();
                con.Close();

                tb地址.Text = "";
                tb姓名.Text = "";
                tb電話.Text = "";
                tb顧客代號.Text = "";
                cmb性別.Text = "";
                dtp生日.Value = DateTime.Now;
                tb備註.Text = "";
            }
            else
            {
                MessageBox.Show("請輸入 姓名 查詢");
                tb地址.Text = "";
                tb姓名.Text = "";
                tb電話.Text = "";
                tb顧客代號.Text = "";
                cmb性別.Text = "";
                dtp生日.Value = DateTime.Now;
                tb備註.Text = "";
            }
        }

        void customerList()
        {
            lbox顧客姓名.Items.Clear();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select * from Customer";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                lbox顧客姓名.Items.Add(reader["姓名"]);
            }
            reader.Close();
            con.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp_MOS_test
{
    public partial class products : Form
    {
        SqlConnectionStringBuilder scsb;

        public products()
        {
            InitializeComponent();
        }

        private void products_Load(object sender, EventArgs e)
        {//連到資料庫
            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @".";
            scsb.InitialCatalog = "MOSTest";
            scsb.IntegratedSecurity = true;

        }

        private void btn新增_Click(object sender, EventArgs e)
        {
            pro_create myP_create = new pro_create();
            myP_create.ShowDialog();
            
        }

        private void btn產品列表_Click(object sender, EventArgs e)
        {
            lbox品名.Items.Clear();  //沒清除會無限重複顯示相同內容

            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select * from Products";
            SqlCommand cmd = new SqlCommand(strSQL, con);

            SqlDataReader reader = cmd.ExecuteReader();  //資料存在reader

            while(reader.Read())
            {
                lbox品名.Items.Add(reader["品名"]);
                //cmb品名.Items.Add(reader["品名"]);
            }

            reader.Close();
            con.Close();
        }

        private void btn清除全部_Click(object sender, EventArgs e)
        {
            tb代號.Text = "";
            tb品名.Text = "";
            tb單價.Text = "";
            tb規格.Text = "";            
            lbox品名.Items.Clear();
        }

        private void btn刪除_Click(object sender, EventArgs e)
        {
            int intID = 0;
            Int32.TryParse(tb代號.Text, out intID);

            if (intID > 0)
            {
                DialogResult R;
                R = MessageBox.Show("您確定要 刪除 該筆資料?", "刪除確認", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (R == DialogResult.Yes)
                {

                    SqlConnection con = new SqlConnection(scsb.ToString());
                    con.Open();
                    string strSQL = "delete from Products where 產品代號 = @SearchID";
                    SqlCommand cmd = new SqlCommand(strSQL, con);
                    cmd.Parameters.AddWithValue("@SearchID", intID);

                    //清空欄位
                    tb代號.Text = "";
                    tb品名.Text = "";
                    tb單價.Text = "";
                    tb規格.Text = "";
                    lbox品名.Items.Clear();

                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                else
                {

                }
            }
            else
            {
                MessageBox.Show("請先選擇欲刪除之產品,再行刪除");
            }


        }

        private void lbox品名_SelectedIndexChanged(object sender, EventArgs e)
        {//在lbox點選項目,左側欄位會顯示產品資料
            string strName = lbox品名.SelectedItem.ToString();

            if (strName != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select * from Products where 品名 like @SearchName";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchName", "%" + strName + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    tb代號.Text = string.Format("{0}", reader["產品代號"]);
                    tb品名.Text = string.Format("{0}", reader["品名"]);
                    tb單價.Text = string.Format("{0}", reader["單價"]);
                    tb規格.Text = string.Format("{0}", reader["規格"]);
                }
                else
                {
                    MessageBox.Show("無此產品");
                    tb代號.Text = "";
                    tb品名.Text = "";
                    tb單價.Text = "";                    
                    tb規格.Text = "";
                }

                reader.Close();
                con.Close();
            }
            else
            {
                MessageBox.Show("請點選 產品列表 或 查詢");
            }


        }

        private void btn修改_Click(object sender, EventArgs e)
        {
            pro_update myP_update = new pro_update();
            

            int intID = 0;
            Int32.TryParse(tb代號.Text, out intID);

            if (intID > 0)
            {
                myP_update.strID = tb代號.Text;
                myP_update.strName = tb品名.Text;
                myP_update.strSize = tb規格.Text;
                myP_update.strPrice = tb單價.Text;

                myP_update.ShowDialog();

                tb代號.Text = "";
                tb品名.Text = "";
                tb單價.Text = "";
                tb規格.Text = "";
                lbox品名.Items.Clear();
            }
            else
            {
                MessageBox.Show("請選擇欲 修改 之產品");
            }



            /*
            int intID = 0;
            Int32.TryParse(tb代號.Text, out intID);

            if (intID > 0)
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "update Products set 品名=@NewName, 規格=@NewSize, 單價=@NewPrice where 產品代號=@SearchID";
                SqlCommand cmd = new SqlCommand(strSQL,con);

                cmd.Parameters.AddWithValue("@SearchID", intID);
                cmd.Parameters.AddWithValue("@NewName", tb品名.Text);
                cmd.Parameters.AddWithValue("@NewSize", tb規格.Text);
                cmd.Parameters.AddWithValue("@NewPrice", tb單價.Text);

                cmd.ExecuteNonQuery();
                con.Close();
                
            }
            else
            {
                MessageBox.Show("請選擇欲 修改 之產品");
            }
            */
        }

        private void btn查詢_Click(object sender, EventArgs e)
        {
            lbox品名.Items.Clear();

            if (tb查詢結果.Text != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select * from Products where 品名 like @SearchName ";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchName", "%" + tb品名.Text + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)  //.HasRows可以, .read == true 會出錯????????????
                {                    
                    while (reader.Read())
                    {
                        lbox品名.Items.Add(reader["品名"]);
                    }
                   
                }
                else
                {
                    lbox品名.Items.Add("查無此產品");
                    tb代號.Text = "";
                    tb品名.Text = "";
                    tb單價.Text = "";
                    tb規格.Text = "";
                }

                reader.Close();
                con.Close();

                tb代號.Text = "";
                tb品名.Text = "";
                tb單價.Text = "";
                tb規格.Text = "";
            }
            else
            {
                MessageBox.Show("請輸入 品名 查詢");
                tb代號.Text = "";
                tb品名.Text = "";
                tb單價.Text = "";
                tb規格.Text = "";
            }
            
        }
    }
}

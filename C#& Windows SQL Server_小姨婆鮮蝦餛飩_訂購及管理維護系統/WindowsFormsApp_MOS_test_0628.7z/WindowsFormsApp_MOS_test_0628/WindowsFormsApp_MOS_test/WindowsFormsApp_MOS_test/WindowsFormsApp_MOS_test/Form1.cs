﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp_MOS_test
{
    public partial class Form1 : Form
    {
        SqlConnectionStringBuilder scsb;

        int Qty = 0, sumItem = 0, unitPrice = 0, shipping = 0;
        DataTable dt = new DataTable();




        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {                     
            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @".";
            scsb.InitialCatalog = "MOSTest";
            scsb.IntegratedSecurity = true;


            ListMenu();
            Listcustomers();

            lbl日期.Text = string.Format("{0:D}", DateTime.Now);

            showUserOrders();

            cmb取貨方式.Text = "自取";
            cmb取貨情形.Text = "已取貨";
            cmb付款情形.Text = "已付款";

            total();


        }

        private void btn產品管理_Click(object sender, EventArgs e)
        {
            products myProducts = new products();
            myProducts.ShowDialog();
        }

        private void btn會員管理_Click(object sender, EventArgs e)
        {
            customers myCustomers = new customers();
            myCustomers.ShowDialog();
        }

        private void btn訂單管理_Click(object sender, EventArgs e)
        {

        }

        private void lbox菜單_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strName = lbox菜單.SelectedItem.ToString();

            if (strName != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select * from Products where 品名 like @SearchName";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchName", "%" + strName + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {

                    tb品名.Text = string.Format("{0}", reader["品名"]);
                    tb單價.Text = string.Format("{0}", reader["單價"]);
                    tb規格.Text = string.Format("{0}", reader["規格"]);
                    tb產品代號.Text = string.Format("{0}", reader["產品代號"]);
                }
                else
                {
                    MessageBox.Show("無此產品");

                    tb品名.Text = "";
                    tb單價.Text = "";
                    tb規格.Text = "";
                }

                reader.Close();
                con.Close();
            }
            else
            {
                MessageBox.Show("請點選 菜單");
            }
        }

        




        private void btn取消_Click(object sender, EventArgs e)
        {
            allClear();
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            Qty -= 1;
            if (Qty <= 0)
            {
                Qty = 0;
                btnMinus.Enabled = false;
            }
            tb數量.Text = Qty.ToString();
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            Qty += 1;
            btnMinus.Enabled = true;
            tb數量.Text = Qty.ToString();

        }

        private void tb數量_TextChanged(object sender, EventArgs e)
        {
            
            if (tb數量.Text != "")
            {
                //判斷是否為int
                bool ifNum = System.Int32.TryParse(tb數量.Text, out Qty);

                if ((ifNum == true)&&(Qty >= 0))
                {
                    btnMinus.Enabled = true;
                }
                else
                {
                    MessageBox.Show("訂購數量輸入錯誤");
                    Qty = 0;
                    tb數量.Text = "0";
                }
            }
            else
            {
                MessageBox.Show("請輸入訂購數量");
                Qty = 0;
                tb數量.Text = "0";
            }

            total();
        }

        private void btn確定_Click(object sender, EventArgs e)
        {
            if (tb品名.Text != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "insert into userOrders values (@NewName, @NewSize, @NewPrice, @NewQty, @NewSum, @NewShipFee);"+
                                "insert into Order_Details (項次, 品名, 數量, 小計, 運費) select 項次, 品名, 數量, 小計, 運費 from userOrders" +
                                "insert into Orders (單號) select 單號 from Order_Details" +
                                "insert into Orders (產品代號, 客戶代號, 總計, 取貨方式, 付款情形, 取貨情形, 交易日期 ) values ( @NewProCode, @NewCusCode, @NewTotal, @NewShipping, @NewPayment, @NewPickup, @NewDate);";
                SqlCommand cmd = new SqlCommand(strSQL, con);

                cmd.Parameters.AddWithValue("@NewName", tb品名.Text);
                cmd.Parameters.AddWithValue("@NewSize", tb規格.Text);
                cmd.Parameters.AddWithValue("@NewPrice", tb單價.Text);
                cmd.Parameters.AddWithValue("@NewQty", tb數量.Text);
                cmd.Parameters.AddWithValue("@NewSum", tb小計.Text);
                cmd.Parameters.AddWithValue("@NewShipFee", tb運費.Text);


                cmd.Parameters.AddWithValue("@NewProCode", tb產品代號.Text);
                cmd.Parameters.AddWithValue("@NewCusCode", tb顧客代號.Text);
                cmd.Parameters.AddWithValue("@NewTotal3", tb總額.Text);
                cmd.Parameters.AddWithValue("@NewShipping", cmb取貨方式.Text);
                cmd.Parameters.AddWithValue("@NewPayment", cmb付款情形.Text);
                cmd.Parameters.AddWithValue("@NewPickup", cmb取貨情形.Text);
                cmd.Parameters.AddWithValue("@NewDate", DateTime.Now);


                cmd.ExecuteNonQuery();               
                showUserOrders();
                con.Close();                
            }
            else
            {
                MessageBox.Show("請至少選擇一個品項");
            }

            allClear();
        }

        private void tb運費_TextChanged(object sender, EventArgs e)
        {
            total();
        }

        private void cmb取貨方式_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb取貨方式.Text == "宅配")
            {
                tb運費.Enabled = true;
                cmb取貨情形.Text = "未取貨";
                
            }
            else
            {
                tb運費.Enabled = false;
            }
        }

        private void btn結帳_Click(object sender, EventArgs e)
        {
            allClear();

            dt.Clear();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            //刪除所有資料,並重置 IDENTITY 數值
            string sqlTruncate = "truncate table userOrders";
            SqlCommand cmd = new SqlCommand(sqlTruncate, con);
            cmd.ExecuteNonQuery();
            con.Close();

        }

        private void total()
        {
            
            //單價轉int
            Int32.TryParse(tb單價.Text, out unitPrice);
            Int32.TryParse(tb數量.Text, out Qty);
            Int32.TryParse(tb運費.Text, out shipping);

            sumItem = unitPrice * Qty; //小計
            tb小計.Text = sumItem.ToString();

            //sum = unitPrice * Qty + shipping;

            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select (sum (小計)+ sum(運費)) as 總計 from userOrders"; //多筆總計
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();
            
            if (reader.Read())
            {
                tb總額.Text = string.Format("{0}",reader["總計"]);
            }

            reader.Close();
            con.Close();
            
        }

        private void allClear()
        {
            tb品名.Text = "";
            tb單價.Text = "";
            tb小計.Text = "";
            tb總額.Text = "";
            tb規格.Text = "";
            tb運費.Text = "";
            cmb取貨方式.Text = "自取";
            tb數量.Text = "0";
            cmb顧客姓名.Text = "";
            cmb取貨情形.Text = "已取貨";
            cmb付款情形.Text = "已付款";

        }

        private void cmb顧客姓名_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strName = cmb顧客姓名.SelectedItem.ToString();

            if (strName != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select * from Customer where 姓名 like @SearchName";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchName", "%" + strName + "%");
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    tb顧客代號.Text = string.Format("{0}", reader["客戶代號"]);                    
                }
                else
                {
                    MessageBox.Show("無此客戶代號");
                    tb顧客代號.Text = "";
                }

                reader.Close();
                con.Close();
            }
            else
            {
                MessageBox.Show("無字串");
            }
        }

        private void ListMenu()
        {
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select * from Products";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                lbox菜單.Items.Add(reader["品名"]);
            }
            reader.Close();
            con.Close();
        }

        

        private void Listcustomers()
        {
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select * from Customer";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                cmb顧客姓名.Items.Add(reader["姓名"]);
            }
            reader.Close();
            con.Close();
        }

        private void showUserOrders()
        {
            dt.Clear();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select * from userOrders";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();
            //DataTable dt = new DataTable();
            dt.Load(reader);
            dgvUserOrders.DataSource = dt;
            con.Close();
        }












        










    }
}

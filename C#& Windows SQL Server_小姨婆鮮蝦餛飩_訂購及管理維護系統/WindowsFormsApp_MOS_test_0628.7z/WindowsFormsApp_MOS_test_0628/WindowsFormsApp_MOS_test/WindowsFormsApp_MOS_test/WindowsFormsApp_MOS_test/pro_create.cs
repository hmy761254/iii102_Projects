﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp_MOS_test
{
    public partial class pro_create : Form
    {

        SqlConnectionStringBuilder scsb;

        public pro_create()
        {
            InitializeComponent();
        }

        private void pro_create_Load(object sender, EventArgs e)
        {
            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @".";
            scsb.InitialCatalog = "MOSTest";
            scsb.IntegratedSecurity = true;
        }

        private void btn確定_Click(object sender, EventArgs e)
        {
            if (tb品名.Text != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "insert into Products values(@NewName,@NewSize,@NewPrice)";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@NewName", tb品名.Text);
                cmd.Parameters.AddWithValue("@NewSize", tb規格.Text);
                cmd.Parameters.AddWithValue("@NewPrice", tb單價.Text);// 型別轉換(int)??????????????目前顯示沒問題


                cmd.ExecuteNonQuery();  //沒有ExecuteNonQuery() 動作不會成功
                con.Close();
                //MessageBox.Show("資料新增完畢,共 " + rows.ToString() + " 筆");
                Close();
            }
            else
            {
                MessageBox.Show("請至少輸入 品名 ");
            }
        }

        private void btn取消_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

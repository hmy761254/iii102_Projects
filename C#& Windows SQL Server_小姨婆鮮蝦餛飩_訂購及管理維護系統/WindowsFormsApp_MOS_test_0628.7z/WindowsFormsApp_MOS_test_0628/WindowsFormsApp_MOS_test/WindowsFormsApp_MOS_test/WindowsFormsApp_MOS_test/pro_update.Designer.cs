﻿namespace WindowsFormsApp_MOS_test
{
    partial class pro_update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb單價 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb規格 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb品名 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb代號 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btn取消 = new System.Windows.Forms.Button();
            this.btn確定 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(35, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 37);
            this.label1.TabIndex = 83;
            this.label1.Text = "修改產品資料";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CadetBlue;
            this.panel1.Controls.Add(this.tb單價);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.tb規格);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.tb品名);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.tb代號);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(33, 91);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(337, 285);
            this.panel1.TabIndex = 87;
            // 
            // tb單價
            // 
            this.tb單價.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb單價.Location = new System.Drawing.Point(83, 219);
            this.tb單價.Name = "tb單價";
            this.tb單價.Size = new System.Drawing.Size(208, 35);
            this.tb單價.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(18, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 26);
            this.label5.TabIndex = 67;
            this.label5.Text = "單價:";
            // 
            // tb規格
            // 
            this.tb規格.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb規格.Location = new System.Drawing.Point(83, 151);
            this.tb規格.Name = "tb規格";
            this.tb規格.Size = new System.Drawing.Size(208, 35);
            this.tb規格.TabIndex = 66;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(18, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 26);
            this.label3.TabIndex = 65;
            this.label3.Text = "規格:";
            // 
            // tb品名
            // 
            this.tb品名.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb品名.Location = new System.Drawing.Point(83, 84);
            this.tb品名.Name = "tb品名";
            this.tb品名.Size = new System.Drawing.Size(208, 35);
            this.tb品名.TabIndex = 64;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(18, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 26);
            this.label2.TabIndex = 63;
            this.label2.Text = "品名:";
            // 
            // tb代號
            // 
            this.tb代號.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb代號.Location = new System.Drawing.Point(83, 19);
            this.tb代號.Name = "tb代號";
            this.tb代號.Size = new System.Drawing.Size(208, 35);
            this.tb代號.TabIndex = 62;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(18, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 26);
            this.label4.TabIndex = 61;
            this.label4.Text = "代號:";
            // 
            // btn取消
            // 
            this.btn取消.BackColor = System.Drawing.Color.Gainsboro;
            this.btn取消.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn取消.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn取消.Location = new System.Drawing.Point(228, 417);
            this.btn取消.Name = "btn取消";
            this.btn取消.Size = new System.Drawing.Size(96, 57);
            this.btn取消.TabIndex = 89;
            this.btn取消.Text = "取消";
            this.btn取消.UseVisualStyleBackColor = false;
            this.btn取消.Click += new System.EventHandler(this.btn取消_Click);
            // 
            // btn確定
            // 
            this.btn確定.BackColor = System.Drawing.Color.Gainsboro;
            this.btn確定.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn確定.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn確定.Location = new System.Drawing.Point(74, 417);
            this.btn確定.Name = "btn確定";
            this.btn確定.Size = new System.Drawing.Size(96, 57);
            this.btn確定.TabIndex = 88;
            this.btn確定.Text = "確定";
            this.btn確定.UseVisualStyleBackColor = false;
            this.btn確定.Click += new System.EventHandler(this.btn確定_Click);
            // 
            // pro_update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(414, 512);
            this.Controls.Add(this.btn取消);
            this.Controls.Add(this.btn確定);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Name = "pro_update";
            this.Text = "修改產品資料";
            this.Load += new System.EventHandler(this.pro_update_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tb單價;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb規格;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb品名;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb代號;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn取消;
        private System.Windows.Forms.Button btn確定;
    }
}
﻿namespace WindowsFormsApp_MOS_test
{
    partial class cus_update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn取消 = new System.Windows.Forms.Button();
            this.btn確定 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbu顧客代號 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbu備註 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbu性別 = new System.Windows.Forms.ComboBox();
            this.dtpu生日 = new System.Windows.Forms.DateTimePicker();
            this.tbu地址 = new System.Windows.Forms.TextBox();
            this.tbu電話 = new System.Windows.Forms.TextBox();
            this.tbu姓名 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(30, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 37);
            this.label1.TabIndex = 82;
            this.label1.Text = "修改顧客資料";
            // 
            // btn取消
            // 
            this.btn取消.BackColor = System.Drawing.Color.Gainsboro;
            this.btn取消.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn取消.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn取消.Location = new System.Drawing.Point(335, 614);
            this.btn取消.Name = "btn取消";
            this.btn取消.Size = new System.Drawing.Size(95, 58);
            this.btn取消.TabIndex = 81;
            this.btn取消.Text = "取消";
            this.btn取消.UseVisualStyleBackColor = false;
            this.btn取消.Click += new System.EventHandler(this.btn取消_Click);
            // 
            // btn確定
            // 
            this.btn確定.BackColor = System.Drawing.Color.Gainsboro;
            this.btn確定.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn確定.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn確定.Location = new System.Drawing.Point(175, 614);
            this.btn確定.Name = "btn確定";
            this.btn確定.Size = new System.Drawing.Size(95, 58);
            this.btn確定.TabIndex = 80;
            this.btn確定.Text = "確定";
            this.btn確定.UseVisualStyleBackColor = false;
            this.btn確定.Click += new System.EventHandler(this.btn確定_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.CadetBlue;
            this.panel2.Controls.Add(this.tbu顧客代號);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.tbu備註);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.cmbu性別);
            this.panel2.Controls.Add(this.dtpu生日);
            this.panel2.Controls.Add(this.tbu地址);
            this.panel2.Controls.Add(this.tbu電話);
            this.panel2.Controls.Add(this.tbu姓名);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(38, 90);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(539, 497);
            this.panel2.TabIndex = 79;
            // 
            // tbu顧客代號
            // 
            this.tbu顧客代號.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tbu顧客代號.Location = new System.Drawing.Point(86, 29);
            this.tbu顧客代號.Name = "tbu顧客代號";
            this.tbu顧客代號.Size = new System.Drawing.Size(154, 35);
            this.tbu顧客代號.TabIndex = 79;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(21, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 26);
            this.label4.TabIndex = 78;
            this.label4.Text = "代號:";
            // 
            // tbu備註
            // 
            this.tbu備註.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tbu備註.Location = new System.Drawing.Point(86, 367);
            this.tbu備註.Multiline = true;
            this.tbu備註.Name = "tbu備註";
            this.tbu備註.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbu備註.Size = new System.Drawing.Size(416, 92);
            this.tbu備註.TabIndex = 77;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(21, 370);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 26);
            this.label8.TabIndex = 76;
            this.label8.Text = "備註:";
            // 
            // cmbu性別
            // 
            this.cmbu性別.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmbu性別.FormattingEnabled = true;
            this.cmbu性別.Items.AddRange(new object[] {
            "男",
            "女"});
            this.cmbu性別.Location = new System.Drawing.Point(86, 138);
            this.cmbu性別.Name = "cmbu性別";
            this.cmbu性別.Size = new System.Drawing.Size(80, 34);
            this.cmbu性別.TabIndex = 75;
            // 
            // dtpu生日
            // 
            this.dtpu生日.CalendarFont = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dtpu生日.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dtpu生日.Location = new System.Drawing.Point(86, 197);
            this.dtpu生日.Name = "dtpu生日";
            this.dtpu生日.Size = new System.Drawing.Size(197, 35);
            this.dtpu生日.TabIndex = 66;
            // 
            // tbu地址
            // 
            this.tbu地址.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tbu地址.Location = new System.Drawing.Point(86, 309);
            this.tbu地址.Name = "tbu地址";
            this.tbu地址.Size = new System.Drawing.Size(416, 35);
            this.tbu地址.TabIndex = 65;
            // 
            // tbu電話
            // 
            this.tbu電話.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tbu電話.Location = new System.Drawing.Point(86, 250);
            this.tbu電話.Name = "tbu電話";
            this.tbu電話.Size = new System.Drawing.Size(197, 35);
            this.tbu電話.TabIndex = 64;
            // 
            // tbu姓名
            // 
            this.tbu姓名.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tbu姓名.Location = new System.Drawing.Point(86, 86);
            this.tbu姓名.Name = "tbu姓名";
            this.tbu姓名.Size = new System.Drawing.Size(151, 35);
            this.tbu姓名.TabIndex = 61;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(21, 312);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 26);
            this.label7.TabIndex = 59;
            this.label7.Text = "地址:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(21, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 26);
            this.label6.TabIndex = 58;
            this.label6.Text = "電話:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(21, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 26);
            this.label5.TabIndex = 57;
            this.label5.Text = "生日:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(21, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 26);
            this.label3.TabIndex = 56;
            this.label3.Text = "性別:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(21, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 26);
            this.label2.TabIndex = 55;
            this.label2.Text = "姓名:";
            // 
            // cus_update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(615, 708);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn取消);
            this.Controls.Add(this.btn確定);
            this.Controls.Add(this.panel2);
            this.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Name = "cus_update";
            this.Text = "修改顧客資料";
            this.Load += new System.EventHandler(this.cus_update_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn取消;
        private System.Windows.Forms.Button btn確定;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbu備註;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbu性別;
        private System.Windows.Forms.DateTimePicker dtpu生日;
        private System.Windows.Forms.TextBox tbu地址;
        private System.Windows.Forms.TextBox tbu電話;
        private System.Windows.Forms.TextBox tbu姓名;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbu顧客代號;
        private System.Windows.Forms.Label label4;
    }
}
﻿namespace WindowsFormsApp_MOS_test
{
    partial class pro_create
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn取消 = new System.Windows.Forms.Button();
            this.btn確定 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb單價 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb規格 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb品名 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn退出 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(92, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 35);
            this.label1.TabIndex = 82;
            this.label1.Text = "新增產品資料";
            // 
            // btn取消
            // 
            this.btn取消.BackColor = System.Drawing.Color.Gainsboro;
            this.btn取消.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn取消.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn取消.Location = new System.Drawing.Point(141, 339);
            this.btn取消.Name = "btn取消";
            this.btn取消.Size = new System.Drawing.Size(92, 51);
            this.btn取消.TabIndex = 81;
            this.btn取消.Text = "取消";
            this.btn取消.UseVisualStyleBackColor = false;
            this.btn取消.Click += new System.EventHandler(this.btn取消_Click);
            // 
            // btn確定
            // 
            this.btn確定.BackColor = System.Drawing.Color.Gainsboro;
            this.btn確定.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn確定.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn確定.Location = new System.Drawing.Point(34, 339);
            this.btn確定.Name = "btn確定";
            this.btn確定.Size = new System.Drawing.Size(95, 51);
            this.btn確定.TabIndex = 80;
            this.btn確定.Text = "確定";
            this.btn確定.UseVisualStyleBackColor = false;
            this.btn確定.Click += new System.EventHandler(this.btn確定_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CadetBlue;
            this.panel1.Controls.Add(this.tb單價);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.tb規格);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.tb品名);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(34, 83);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(339, 227);
            this.panel1.TabIndex = 87;
            // 
            // tb單價
            // 
            this.tb單價.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb單價.Location = new System.Drawing.Point(92, 160);
            this.tb單價.Name = "tb單價";
            this.tb單價.Size = new System.Drawing.Size(208, 35);
            this.tb單價.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(19, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 26);
            this.label5.TabIndex = 67;
            this.label5.Text = "單價:";
            // 
            // tb規格
            // 
            this.tb規格.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb規格.Location = new System.Drawing.Point(92, 92);
            this.tb規格.Name = "tb規格";
            this.tb規格.Size = new System.Drawing.Size(208, 35);
            this.tb規格.TabIndex = 66;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(19, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 26);
            this.label3.TabIndex = 65;
            this.label3.Text = "規格:";
            // 
            // tb品名
            // 
            this.tb品名.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb品名.Location = new System.Drawing.Point(92, 25);
            this.tb品名.Name = "tb品名";
            this.tb品名.Size = new System.Drawing.Size(208, 35);
            this.tb品名.TabIndex = 64;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(19, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 26);
            this.label2.TabIndex = 63;
            this.label2.Text = "品名:";
            // 
            // btn退出
            // 
            this.btn退出.BackColor = System.Drawing.Color.Gainsboro;
            this.btn退出.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn退出.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn退出.Location = new System.Drawing.Point(247, 340);
            this.btn退出.Name = "btn退出";
            this.btn退出.Size = new System.Drawing.Size(126, 50);
            this.btn退出.TabIndex = 98;
            this.btn退出.Text = "退出頁面";
            this.btn退出.UseVisualStyleBackColor = false;
            this.btn退出.Click += new System.EventHandler(this.btn退出_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp_MOS_test.Properties.Resources.product;
            this.pictureBox1.Location = new System.Drawing.Point(35, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(52, 53);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 99;
            this.pictureBox1.TabStop = false;
            // 
            // pro_create
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(411, 427);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn退出);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn取消);
            this.Controls.Add(this.btn確定);
            this.Name = "pro_create";
            this.Text = "新增產品資料";
            this.Load += new System.EventHandler(this.pro_create_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn取消;
        private System.Windows.Forms.Button btn確定;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tb單價;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb規格;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb品名;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn退出;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
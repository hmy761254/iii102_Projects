﻿namespace WindowsFormsApp_MOS_test
{
    partial class cus_create
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.tb備註 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmb性別 = new System.Windows.Forms.ComboBox();
            this.dtp生日 = new System.Windows.Forms.DateTimePicker();
            this.tb地址 = new System.Windows.Forms.TextBox();
            this.tb電話 = new System.Windows.Forms.TextBox();
            this.tb姓名 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn確定 = new System.Windows.Forms.Button();
            this.btn取消 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn退出 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.CadetBlue;
            this.panel2.Controls.Add(this.tb備註);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.cmb性別);
            this.panel2.Controls.Add(this.dtp生日);
            this.panel2.Controls.Add(this.tb地址);
            this.panel2.Controls.Add(this.tb電話);
            this.panel2.Controls.Add(this.tb姓名);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(39, 86);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(542, 436);
            this.panel2.TabIndex = 75;
            // 
            // tb備註
            // 
            this.tb備註.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb備註.Location = new System.Drawing.Point(89, 308);
            this.tb備註.Multiline = true;
            this.tb備註.Name = "tb備註";
            this.tb備註.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb備註.Size = new System.Drawing.Size(416, 92);
            this.tb備註.TabIndex = 77;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(17, 311);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 26);
            this.label8.TabIndex = 76;
            this.label8.Text = "備註:";
            // 
            // cmb性別
            // 
            this.cmb性別.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmb性別.FormattingEnabled = true;
            this.cmb性別.Items.AddRange(new object[] {
            "男",
            "女"});
            this.cmb性別.Location = new System.Drawing.Point(89, 79);
            this.cmb性別.Name = "cmb性別";
            this.cmb性別.Size = new System.Drawing.Size(80, 34);
            this.cmb性別.TabIndex = 75;
            // 
            // dtp生日
            // 
            this.dtp生日.CalendarFont = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dtp生日.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dtp生日.Location = new System.Drawing.Point(89, 138);
            this.dtp生日.Name = "dtp生日";
            this.dtp生日.Size = new System.Drawing.Size(197, 35);
            this.dtp生日.TabIndex = 66;
            // 
            // tb地址
            // 
            this.tb地址.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb地址.Location = new System.Drawing.Point(89, 250);
            this.tb地址.Name = "tb地址";
            this.tb地址.Size = new System.Drawing.Size(416, 35);
            this.tb地址.TabIndex = 65;
            // 
            // tb電話
            // 
            this.tb電話.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb電話.Location = new System.Drawing.Point(89, 191);
            this.tb電話.Name = "tb電話";
            this.tb電話.Size = new System.Drawing.Size(197, 35);
            this.tb電話.TabIndex = 64;
            // 
            // tb姓名
            // 
            this.tb姓名.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb姓名.Location = new System.Drawing.Point(89, 27);
            this.tb姓名.Name = "tb姓名";
            this.tb姓名.Size = new System.Drawing.Size(151, 35);
            this.tb姓名.TabIndex = 61;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(17, 253);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 26);
            this.label7.TabIndex = 59;
            this.label7.Text = "地址:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(17, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 26);
            this.label6.TabIndex = 58;
            this.label6.Text = "電話:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(17, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 26);
            this.label5.TabIndex = 57;
            this.label5.Text = "生日:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(17, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 26);
            this.label3.TabIndex = 56;
            this.label3.Text = "性別:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(17, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 26);
            this.label2.TabIndex = 55;
            this.label2.Text = "姓名:";
            // 
            // btn確定
            // 
            this.btn確定.BackColor = System.Drawing.Color.Gainsboro;
            this.btn確定.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn確定.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn確定.Location = new System.Drawing.Point(113, 560);
            this.btn確定.Name = "btn確定";
            this.btn確定.Size = new System.Drawing.Size(95, 50);
            this.btn確定.TabIndex = 76;
            this.btn確定.Text = "確定";
            this.btn確定.UseVisualStyleBackColor = false;
            this.btn確定.Click += new System.EventHandler(this.btn確定_Click);
            // 
            // btn取消
            // 
            this.btn取消.BackColor = System.Drawing.Color.Gainsboro;
            this.btn取消.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn取消.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn取消.Location = new System.Drawing.Point(251, 560);
            this.btn取消.Name = "btn取消";
            this.btn取消.Size = new System.Drawing.Size(95, 50);
            this.btn取消.TabIndex = 77;
            this.btn取消.Text = "取消";
            this.btn取消.UseVisualStyleBackColor = false;
            this.btn取消.Click += new System.EventHandler(this.btn取消_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(105, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 37);
            this.label1.TabIndex = 78;
            this.label1.Text = "新增顧客資料";
            // 
            // btn退出
            // 
            this.btn退出.BackColor = System.Drawing.Color.Gainsboro;
            this.btn退出.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn退出.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn退出.Location = new System.Drawing.Point(385, 560);
            this.btn退出.Name = "btn退出";
            this.btn退出.Size = new System.Drawing.Size(126, 50);
            this.btn退出.TabIndex = 99;
            this.btn退出.Text = "退出頁面";
            this.btn退出.UseVisualStyleBackColor = false;
            this.btn退出.Click += new System.EventHandler(this.btn退出_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp_MOS_test.Properties.Resources.cus_;
            this.pictureBox1.Location = new System.Drawing.Point(39, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(65, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 100;
            this.pictureBox1.TabStop = false;
            // 
            // cus_create
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(625, 638);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn退出);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn取消);
            this.Controls.Add(this.btn確定);
            this.Controls.Add(this.panel2);
            this.Name = "cus_create";
            this.Text = "新增顧客";
            this.Load += new System.EventHandler(this.cus_create_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tb備註;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmb性別;
        private System.Windows.Forms.DateTimePicker dtp生日;
        private System.Windows.Forms.TextBox tb地址;
        private System.Windows.Forms.TextBox tb電話;
        private System.Windows.Forms.TextBox tb姓名;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn確定;
        private System.Windows.Forms.Button btn取消;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn退出;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
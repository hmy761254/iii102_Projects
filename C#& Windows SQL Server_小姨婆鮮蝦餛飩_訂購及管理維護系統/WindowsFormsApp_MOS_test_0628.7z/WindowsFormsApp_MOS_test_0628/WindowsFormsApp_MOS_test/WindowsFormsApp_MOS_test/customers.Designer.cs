﻿namespace WindowsFormsApp_MOS_test
{
    partial class customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn刪除 = new System.Windows.Forms.Button();
            this.btn修改 = new System.Windows.Forms.Button();
            this.lbox顧客姓名 = new System.Windows.Forms.ListBox();
            this.btn新增 = new System.Windows.Forms.Button();
            this.btn查詢 = new System.Windows.Forms.Button();
            this.btn顧客列表 = new System.Windows.Forms.Button();
            this.btn清除全部 = new System.Windows.Forms.Button();
            this.tb查詢結果 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tb備註 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmb性別 = new System.Windows.Forms.ComboBox();
            this.dtp生日 = new System.Windows.Forms.DateTimePicker();
            this.tb地址 = new System.Windows.Forms.TextBox();
            this.tb電話 = new System.Windows.Forms.TextBox();
            this.tb姓名 = new System.Windows.Forms.TextBox();
            this.tb顧客代號 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn刪除
            // 
            this.btn刪除.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn刪除.Location = new System.Drawing.Point(400, 558);
            this.btn刪除.Name = "btn刪除";
            this.btn刪除.Size = new System.Drawing.Size(86, 54);
            this.btn刪除.TabIndex = 52;
            this.btn刪除.Text = "刪除";
            this.btn刪除.UseVisualStyleBackColor = true;
            this.btn刪除.Click += new System.EventHandler(this.btn刪除_Click);
            // 
            // btn修改
            // 
            this.btn修改.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn修改.Location = new System.Drawing.Point(292, 558);
            this.btn修改.Name = "btn修改";
            this.btn修改.Size = new System.Drawing.Size(86, 54);
            this.btn修改.TabIndex = 53;
            this.btn修改.Text = "修改";
            this.btn修改.UseVisualStyleBackColor = true;
            this.btn修改.Click += new System.EventHandler(this.btn修改_Click);
            // 
            // lbox顧客姓名
            // 
            this.lbox顧客姓名.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbox顧客姓名.FormattingEnabled = true;
            this.lbox顧客姓名.ItemHeight = 26;
            this.lbox顧客姓名.Location = new System.Drawing.Point(603, 162);
            this.lbox顧客姓名.Name = "lbox顧客姓名";
            this.lbox顧客姓名.Size = new System.Drawing.Size(191, 316);
            this.lbox顧客姓名.TabIndex = 67;
            this.lbox顧客姓名.SelectedIndexChanged += new System.EventHandler(this.lbox顧客姓名_SelectedIndexChanged);
            // 
            // btn新增
            // 
            this.btn新增.BackColor = System.Drawing.Color.Gainsboro;
            this.btn新增.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn新增.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn新增.Location = new System.Drawing.Point(184, 558);
            this.btn新增.Name = "btn新增";
            this.btn新增.Size = new System.Drawing.Size(86, 54);
            this.btn新增.TabIndex = 51;
            this.btn新增.Text = "新增";
            this.btn新增.UseVisualStyleBackColor = false;
            this.btn新增.Click += new System.EventHandler(this.btn新增_Click);
            // 
            // btn查詢
            // 
            this.btn查詢.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btn查詢.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn查詢.Location = new System.Drawing.Point(641, 558);
            this.btn查詢.Name = "btn查詢";
            this.btn查詢.Size = new System.Drawing.Size(117, 54);
            this.btn查詢.TabIndex = 88;
            this.btn查詢.Text = "姓名查詢";
            this.btn查詢.UseVisualStyleBackColor = false;
            this.btn查詢.Click += new System.EventHandler(this.btn查詢_Click);
            // 
            // btn顧客列表
            // 
            this.btn顧客列表.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btn顧客列表.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn顧客列表.Location = new System.Drawing.Point(603, 88);
            this.btn顧客列表.Name = "btn顧客列表";
            this.btn顧客列表.Size = new System.Drawing.Size(191, 56);
            this.btn顧客列表.TabIndex = 91;
            this.btn顧客列表.Text = "顧客列表";
            this.btn顧客列表.UseVisualStyleBackColor = false;
            this.btn顧客列表.Click += new System.EventHandler(this.btn顧客列表_Click);
            // 
            // btn清除全部
            // 
            this.btn清除全部.BackColor = System.Drawing.Color.DarkGray;
            this.btn清除全部.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn清除全部.Location = new System.Drawing.Point(29, 558);
            this.btn清除全部.Name = "btn清除全部";
            this.btn清除全部.Size = new System.Drawing.Size(122, 54);
            this.btn清除全部.TabIndex = 92;
            this.btn清除全部.Text = "清除全部";
            this.btn清除全部.UseVisualStyleBackColor = false;
            this.btn清除全部.Click += new System.EventHandler(this.btn清除全部_Click);
            // 
            // tb查詢結果
            // 
            this.tb查詢結果.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tb查詢結果.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb查詢結果.Location = new System.Drawing.Point(605, 501);
            this.tb查詢結果.Name = "tb查詢結果";
            this.tb查詢結果.Size = new System.Drawing.Size(191, 35);
            this.tb查詢結果.TabIndex = 78;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.CadetBlue;
            this.panel2.Controls.Add(this.tb備註);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.cmb性別);
            this.panel2.Controls.Add(this.dtp生日);
            this.panel2.Controls.Add(this.tb地址);
            this.panel2.Controls.Add(this.tb電話);
            this.panel2.Controls.Add(this.tb姓名);
            this.panel2.Controls.Add(this.tb顧客代號);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(29, 88);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(547, 448);
            this.panel2.TabIndex = 74;
            // 
            // tb備註
            // 
            this.tb備註.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb備註.Location = new System.Drawing.Point(85, 352);
            this.tb備註.Multiline = true;
            this.tb備註.Name = "tb備註";
            this.tb備註.ReadOnly = true;
            this.tb備註.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb備註.Size = new System.Drawing.Size(432, 67);
            this.tb備註.TabIndex = 77;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(15, 355);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 26);
            this.label8.TabIndex = 76;
            this.label8.Text = "備註:";
            // 
            // cmb性別
            // 
            this.cmb性別.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmb性別.FormattingEnabled = true;
            this.cmb性別.Items.AddRange(new object[] {
            "男",
            "女"});
            this.cmb性別.Location = new System.Drawing.Point(85, 123);
            this.cmb性別.Name = "cmb性別";
            this.cmb性別.Size = new System.Drawing.Size(83, 34);
            this.cmb性別.TabIndex = 75;
            // 
            // dtp生日
            // 
            this.dtp生日.CalendarFont = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dtp生日.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dtp生日.Location = new System.Drawing.Point(85, 182);
            this.dtp生日.Name = "dtp生日";
            this.dtp生日.Size = new System.Drawing.Size(200, 35);
            this.dtp生日.TabIndex = 66;
            // 
            // tb地址
            // 
            this.tb地址.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb地址.Location = new System.Drawing.Point(85, 294);
            this.tb地址.Name = "tb地址";
            this.tb地址.ReadOnly = true;
            this.tb地址.Size = new System.Drawing.Size(432, 35);
            this.tb地址.TabIndex = 65;
            // 
            // tb電話
            // 
            this.tb電話.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb電話.Location = new System.Drawing.Point(85, 235);
            this.tb電話.Name = "tb電話";
            this.tb電話.ReadOnly = true;
            this.tb電話.Size = new System.Drawing.Size(200, 35);
            this.tb電話.TabIndex = 64;
            // 
            // tb姓名
            // 
            this.tb姓名.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb姓名.Location = new System.Drawing.Point(85, 71);
            this.tb姓名.Name = "tb姓名";
            this.tb姓名.ReadOnly = true;
            this.tb姓名.Size = new System.Drawing.Size(154, 35);
            this.tb姓名.TabIndex = 61;
            // 
            // tb顧客代號
            // 
            this.tb顧客代號.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb顧客代號.Location = new System.Drawing.Point(85, 16);
            this.tb顧客代號.Name = "tb顧客代號";
            this.tb顧客代號.ReadOnly = true;
            this.tb顧客代號.Size = new System.Drawing.Size(154, 35);
            this.tb顧客代號.TabIndex = 60;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(15, 297);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 26);
            this.label7.TabIndex = 59;
            this.label7.Text = "地址:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(15, 238);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 26);
            this.label6.TabIndex = 58;
            this.label6.Text = "電話:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(15, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 26);
            this.label5.TabIndex = 57;
            this.label5.Text = "生日:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(15, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 26);
            this.label3.TabIndex = 56;
            this.label3.Text = "性別:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(15, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 26);
            this.label2.TabIndex = 55;
            this.label2.Text = "姓名:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(15, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 26);
            this.label4.TabIndex = 54;
            this.label4.Text = "代號:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(91, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 37);
            this.label1.TabIndex = 50;
            this.label1.Text = "顧客維護";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp_MOS_test.Properties.Resources.pp;
            this.pictureBox1.InitialImage = global::WindowsFormsApp_MOS_test.Properties.Resources.persons;
            this.pictureBox1.Location = new System.Drawing.Point(29, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(60, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 78;
            this.pictureBox1.TabStop = false;
            // 
            // customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(829, 638);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tb查詢結果);
            this.Controls.Add(this.btn清除全部);
            this.Controls.Add(this.btn顧客列表);
            this.Controls.Add(this.btn查詢);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btn新增);
            this.Controls.Add(this.lbox顧客姓名);
            this.Controls.Add(this.btn修改);
            this.Controls.Add(this.btn刪除);
            this.Controls.Add(this.label1);
            this.Name = "customers";
            this.Text = "顧客維護";
            this.Activated += new System.EventHandler(this.customers_Activated);
            this.Load += new System.EventHandler(this.customers_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn刪除;
        private System.Windows.Forms.Button btn修改;
        private System.Windows.Forms.ListBox lbox顧客姓名;
        private System.Windows.Forms.Button btn新增;
        private System.Windows.Forms.Button btn查詢;
        private System.Windows.Forms.Button btn顧客列表;
        private System.Windows.Forms.Button btn清除全部;
        private System.Windows.Forms.TextBox tb查詢結果;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tb備註;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmb性別;
        private System.Windows.Forms.DateTimePicker dtp生日;
        private System.Windows.Forms.TextBox tb地址;
        private System.Windows.Forms.TextBox tb電話;
        private System.Windows.Forms.TextBox tb姓名;
        private System.Windows.Forms.TextBox tb顧客代號;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
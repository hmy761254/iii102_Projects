﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp_MOS_test
{
    public partial class pro_update : Form
    {
        SqlConnectionStringBuilder scsb;

        public pro_update()
        {
            InitializeComponent();
        }

        public string strID;
        public string strName;
        public string strSize;
        public string strPrice;

        private void pro_update_Load(object sender, EventArgs e)
        {
            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @".";
            scsb.InitialCatalog = "MOSTest";
            scsb.IntegratedSecurity = true;

            tb代號.Text = strID;
            tb品名.Text = strName;
            tb規格.Text = strSize;
            tb單價.Text = strPrice;

        }

        private void btn確定_Click(object sender, EventArgs e)
        {
            int intID = 0;
            Int32.TryParse(tb代號.Text, out intID);

            if (intID > 0)
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "update Products set 品名=@NewName, 規格=@NewSize, 單價=@NewPrice where 產品代號=@SearchID";
                SqlCommand cmd = new SqlCommand(strSQL, con);

                cmd.Parameters.AddWithValue("@SearchID", intID);
                cmd.Parameters.AddWithValue("@NewName", tb品名.Text);
                cmd.Parameters.AddWithValue("@NewSize", tb規格.Text);
                cmd.Parameters.AddWithValue("@NewPrice", tb單價.Text);

                cmd.ExecuteNonQuery();
                con.Close();
                Close();
            }
            else
            {
                MessageBox.Show("請選擇欲 修改 之產品");
            }
        }

        private void btn取消_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

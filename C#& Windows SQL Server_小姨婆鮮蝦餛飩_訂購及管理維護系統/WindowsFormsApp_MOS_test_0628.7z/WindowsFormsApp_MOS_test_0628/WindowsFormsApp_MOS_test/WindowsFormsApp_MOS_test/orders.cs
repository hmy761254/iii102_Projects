﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp_MOS_test
{
    public partial class orders : Form
    {
        SqlConnectionStringBuilder scsb;

        DataTable dt_od = new DataTable();

        public orders()
        {
            InitializeComponent();
        }

        private void orders_Load(object sender, EventArgs e)
        {
            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @".";
            scsb.InitialCatalog = "MOSTest";
            scsb.IntegratedSecurity = true;

            showOrderDetails();//table
            showOrderCode();

        }
        private void showOrderDetails()
        {
            dt_od.Clear();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select * from Order_Details";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();
            //DataTable dt = new DataTable();
            dt_od.Load(reader);
            dgvOrderDetails.DataSource = dt_od;
            reader.Close();
            con.Close();
        }
        private void showOrderCode()
        {
            lbox單號.Items.Clear();
            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select * from Orders";
            SqlCommand cmd = new SqlCommand(strSQL, con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                lbox單號.Items.Add(reader["單號"]);
            }
            reader.Close();
            con.Close();
        }

        private void countItems()
        {
            List<string> myList = new List<string>();

            SqlConnection con = new SqlConnection(scsb.ToString());
            con.Open();
            string strSQL = "select * from Order_Details where 單號=@SearchOrCode";
            SqlCommand cmd = new SqlCommand(strSQL, con);

            cmd.Parameters.AddWithValue("@SearchOrCode", lbox單號.Text);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                myList.Add(string.Format("{0}",reader["項次"]));
            }
            
            int j = myList.Count();
            tb項次數量.Text = j.ToString();
            
            reader.Close();
            con.Close();
            
        }        

        private void lbox單號_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbox項次.Items.Clear();

            string strOrCode = lbox單號.SelectedItem.ToString();

            if (strOrCode != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select * from Order_Details where 單號 like @SearchName";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchName", strOrCode);
                SqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    lbox項次.Items.Add(reader["項次"]);
                }

                reader.Close();
                con.Close();
            }

            else
            {
                MessageBox.Show("No data exists");
            }

            countItems();


        }

        private void lbox項次_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strItem = lbox項次.SelectedItem.ToString();
            string strOrCode = lbox單號.SelectedItem.ToString();

            if ((strItem != "")&& (strOrCode != ""))
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "select * from Order_Details where 項次=@SearchItem and 單號=@SearchOrCode";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@SearchItem", strItem);
                cmd.Parameters.AddWithValue("@SearchOrCode", strOrCode);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read() == true)
                {
                    tb品名.Text = string.Format("{0}", reader["品名"]);
                    cmb付款情形.Text = string.Format("{0}", reader["付款情形"]);
                    cmb取貨情形.Text = string.Format("{0}", reader["取貨情形"]);                    
                }
                else
                {
                    MessageBox.Show("無此購買紀錄");

                    tb品名.Text = "";
                    cmb付款情形.Text = "";
                    cmb取貨情形.Text = "";
                }

                reader.Close();
                con.Close();
            }
            else
            {
                MessageBox.Show("請選擇 項次");
            }
            
        }

        private void btn修改_Click(object sender, EventArgs e)
        {
            int intItem = 0, intOrCode = 0;
            Int32.TryParse(lbox項次.Text, out intItem);
            Int32.TryParse(lbox單號.Text, out intOrCode);

            if ((intItem > 0) && (intOrCode > 0))
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "update Order_Details set 付款情形=@NewPayment, 取貨情形=@NewPickup where 項次=@SearchItem and 單號=@SearchOrCode";
                SqlCommand cmd = new SqlCommand(strSQL, con);

                cmd.Parameters.AddWithValue("@NewPayment", cmb付款情形.Text);
                cmd.Parameters.AddWithValue("@NewPickup", cmb取貨情形.Text);
                cmd.Parameters.AddWithValue("@SearchItem", lbox項次.Text);
                cmd.Parameters.AddWithValue("@SearchOrCode", lbox單號.Text);

                cmd.ExecuteNonQuery();
                con.Close();

                tb品名.Text = "";
                cmb付款情形.Text = "";
                cmb取貨情形.Text = "";
                lbox項次.Items.Clear();
                showOrderCode();
                showOrderDetails();
            }
            else
            {
                MessageBox.Show("請選擇欲 修改 之項目");
            }

        }

        private void btn取消_Click(object sender, EventArgs e)
        {
            tb品名.Text = "";
            cmb付款情形.Text = "";
            cmb取貨情形.Text = "";
            lbox項次.Items.Clear();
            showOrderCode();
        }

        private void btn刪除_Click(object sender, EventArgs e)
        {
            int intItem = 0, intOrCode = 0;
            Int32.TryParse(lbox項次.Text, out intItem);
            Int32.TryParse(lbox單號.Text, out intOrCode);

            if ((intItem > 0) && (intOrCode > 0))
            {
                DialogResult R;
                R = MessageBox.Show("您確定要 刪除 該筆資料?", "刪除確認", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if ((R == DialogResult.Yes)&& (tb項次數量.Text == "1"))
                {
                    SqlConnection con = new SqlConnection(scsb.ToString());
                    con.Open();

                    string strSQL = "delete from Order_Details where 項次=@SearchItem and 單號=@SearchOrCode";
                    SqlCommand cmd = new SqlCommand(strSQL, con);

                    cmd.Parameters.AddWithValue("@SearchItem", lbox項次.Text);
                    cmd.Parameters.AddWithValue("@SearchOrCode", lbox單號.Text);

                    cmd.ExecuteNonQuery();


                    //刪掉 只剩1筆的orders訂單
                    string strSQL1 = "delete from Orders where 單號=@SearchOrCode1";
                    SqlCommand cmd1 = new SqlCommand(strSQL1, con);
                    cmd1.Parameters.AddWithValue("@SearchOrCode1", lbox單號.Text);
                    cmd1.ExecuteNonQuery();
                  

                    con.Close();

                    tb品名.Text = "";
                    cmb付款情形.Text = "";
                    cmb取貨情形.Text = "";
                    lbox項次.Items.Clear();

                    showOrderDetails();
                    showOrderCode();

                }
                else
                {

                }
            }
            else
            {
                MessageBox.Show("請先選擇欲刪除之產品");
            }



        }

        private void btn退出_Click(object sender, EventArgs e)
        {
            Close();
            //countItems();
        }
    }
}

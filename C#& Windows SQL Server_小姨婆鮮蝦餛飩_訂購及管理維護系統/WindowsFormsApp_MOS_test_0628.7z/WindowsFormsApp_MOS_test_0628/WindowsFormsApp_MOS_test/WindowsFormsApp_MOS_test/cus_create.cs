﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp_MOS_test
{
    public partial class cus_create : Form
    {
        SqlConnectionStringBuilder scsb;

        public cus_create()
        {
            InitializeComponent();
        }

        private void cus_create_Load(object sender, EventArgs e)
        {
            scsb = new SqlConnectionStringBuilder();
            scsb.DataSource = @".";
            scsb.InitialCatalog = "MOSTest";
            scsb.IntegratedSecurity = true;
        }

        private void btn確定_Click(object sender, EventArgs e)
        {
            if (tb姓名.Text != "")
            {
                SqlConnection con = new SqlConnection(scsb.ToString());
                con.Open();
                string strSQL = "insert into Customer values (@NewName, @NewGender, @NewBirth, @NewTel, @NewAddress, @NewMemo)";
                SqlCommand cmd = new SqlCommand(strSQL, con);
                cmd.Parameters.AddWithValue("@NewName", tb姓名.Text);
                cmd.Parameters.AddWithValue("@NewGender", cmb性別.Text);
                cmd.Parameters.AddWithValue("@NewBirth", (DateTime)dtp生日.Value);
                cmd.Parameters.AddWithValue("@NewTel", tb電話.Text);
                cmd.Parameters.AddWithValue("@NewAddress", tb地址.Text);
                cmd.Parameters.AddWithValue("@NewMemo", tb備註.Text);

                cmd.ExecuteNonQuery();

                //可以讓列表按完確認後自己更新的功能+++++++++++++++++++++++++    activated

                con.Close();

                tb地址.Text = "";
                tb姓名.Text = "";
                tb電話.Text = "";
                cmb性別.Text = "";
                dtp生日.Value = DateTime.Now;
                tb備註.Text = "";

                // customers cusList = new customers();
                //cusList.customerList();

            }
            else
            {
                MessageBox.Show("請至少輸入 姓名");
            }

            
        }

        private void btn取消_Click(object sender, EventArgs e)
        {
            tb地址.Text = "";
            tb姓名.Text = "";
            tb電話.Text = "";            
            cmb性別.Text = "";
            dtp生日.Value = DateTime.Now;            
            tb備註.Text = "";
            
        }

        private void btn退出_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

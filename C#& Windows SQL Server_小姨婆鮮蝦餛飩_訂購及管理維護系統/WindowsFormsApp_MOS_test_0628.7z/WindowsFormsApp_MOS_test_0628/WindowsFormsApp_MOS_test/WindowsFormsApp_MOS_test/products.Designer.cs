﻿namespace WindowsFormsApp_MOS_test
{
    partial class products
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tb代號 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb品名 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb規格 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb單價 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lbox品名 = new System.Windows.Forms.ListBox();
            this.btn新增 = new System.Windows.Forms.Button();
            this.btn修改 = new System.Windows.Forms.Button();
            this.btn刪除 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn產品列表 = new System.Windows.Forms.Button();
            this.btn清除全部 = new System.Windows.Forms.Button();
            this.tb查詢結果 = new System.Windows.Forms.TextBox();
            this.btn查詢 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PowderBlue;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(97, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 37);
            this.label1.TabIndex = 51;
            this.label1.Text = "產品管理";
            // 
            // tb代號
            // 
            this.tb代號.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb代號.Location = new System.Drawing.Point(79, 17);
            this.tb代號.Name = "tb代號";
            this.tb代號.ReadOnly = true;
            this.tb代號.Size = new System.Drawing.Size(208, 35);
            this.tb代號.TabIndex = 62;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(14, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 26);
            this.label4.TabIndex = 61;
            this.label4.Text = "代號:";
            // 
            // tb品名
            // 
            this.tb品名.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb品名.Location = new System.Drawing.Point(79, 69);
            this.tb品名.Name = "tb品名";
            this.tb品名.ReadOnly = true;
            this.tb品名.Size = new System.Drawing.Size(208, 35);
            this.tb品名.TabIndex = 64;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(14, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 26);
            this.label2.TabIndex = 63;
            this.label2.Text = "品名:";
            // 
            // tb規格
            // 
            this.tb規格.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb規格.Location = new System.Drawing.Point(79, 122);
            this.tb規格.Name = "tb規格";
            this.tb規格.ReadOnly = true;
            this.tb規格.Size = new System.Drawing.Size(208, 35);
            this.tb規格.TabIndex = 66;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(14, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 26);
            this.label3.TabIndex = 65;
            this.label3.Text = "規格:";
            // 
            // tb單價
            // 
            this.tb單價.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb單價.Location = new System.Drawing.Point(79, 176);
            this.tb單價.Name = "tb單價";
            this.tb單價.ReadOnly = true;
            this.tb單價.Size = new System.Drawing.Size(208, 35);
            this.tb單價.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(14, 179);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 26);
            this.label5.TabIndex = 67;
            this.label5.Text = "單價:";
            // 
            // lbox品名
            // 
            this.lbox品名.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbox品名.FormattingEnabled = true;
            this.lbox品名.ItemHeight = 26;
            this.lbox品名.Location = new System.Drawing.Point(382, 156);
            this.lbox品名.Name = "lbox品名";
            this.lbox品名.Size = new System.Drawing.Size(200, 238);
            this.lbox品名.TabIndex = 71;
            this.lbox品名.SelectedIndexChanged += new System.EventHandler(this.lbox品名_SelectedIndexChanged);
            // 
            // btn新增
            // 
            this.btn新增.BackColor = System.Drawing.Color.Gainsboro;
            this.btn新增.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn新增.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn新增.Location = new System.Drawing.Point(29, 340);
            this.btn新增.Name = "btn新增";
            this.btn新增.Size = new System.Drawing.Size(79, 54);
            this.btn新增.TabIndex = 77;
            this.btn新增.Text = "新增";
            this.btn新增.UseVisualStyleBackColor = false;
            this.btn新增.Click += new System.EventHandler(this.btn新增_Click);
            // 
            // btn修改
            // 
            this.btn修改.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn修改.Location = new System.Drawing.Point(134, 340);
            this.btn修改.Name = "btn修改";
            this.btn修改.Size = new System.Drawing.Size(79, 54);
            this.btn修改.TabIndex = 79;
            this.btn修改.Text = "修改";
            this.btn修改.UseVisualStyleBackColor = true;
            this.btn修改.Click += new System.EventHandler(this.btn修改_Click);
            // 
            // btn刪除
            // 
            this.btn刪除.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn刪除.Location = new System.Drawing.Point(134, 411);
            this.btn刪除.Name = "btn刪除";
            this.btn刪除.Size = new System.Drawing.Size(79, 54);
            this.btn刪除.TabIndex = 78;
            this.btn刪除.Text = "刪除";
            this.btn刪除.UseVisualStyleBackColor = true;
            this.btn刪除.Click += new System.EventHandler(this.btn刪除_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CadetBlue;
            this.panel1.Controls.Add(this.tb單價);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.tb規格);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.tb品名);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.tb代號);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(29, 86);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(323, 237);
            this.panel1.TabIndex = 86;
            // 
            // btn產品列表
            // 
            this.btn產品列表.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btn產品列表.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn產品列表.ForeColor = System.Drawing.Color.Black;
            this.btn產品列表.Location = new System.Drawing.Point(382, 86);
            this.btn產品列表.Name = "btn產品列表";
            this.btn產品列表.Size = new System.Drawing.Size(200, 56);
            this.btn產品列表.TabIndex = 90;
            this.btn產品列表.Text = "產品列表";
            this.btn產品列表.UseVisualStyleBackColor = false;
            this.btn產品列表.Click += new System.EventHandler(this.btn產品列表_Click);
            // 
            // btn清除全部
            // 
            this.btn清除全部.BackColor = System.Drawing.Color.DarkGray;
            this.btn清除全部.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn清除全部.Location = new System.Drawing.Point(237, 340);
            this.btn清除全部.Name = "btn清除全部";
            this.btn清除全部.Size = new System.Drawing.Size(115, 54);
            this.btn清除全部.TabIndex = 91;
            this.btn清除全部.Text = "清除全部";
            this.btn清除全部.UseVisualStyleBackColor = false;
            this.btn清除全部.Click += new System.EventHandler(this.btn清除全部_Click);
            // 
            // tb查詢結果
            // 
            this.tb查詢結果.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tb查詢結果.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb查詢結果.Location = new System.Drawing.Point(382, 422);
            this.tb查詢結果.Name = "tb查詢結果";
            this.tb查詢結果.Size = new System.Drawing.Size(200, 35);
            this.tb查詢結果.TabIndex = 92;
            // 
            // btn查詢
            // 
            this.btn查詢.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btn查詢.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn查詢.Location = new System.Drawing.Point(236, 411);
            this.btn查詢.Name = "btn查詢";
            this.btn查詢.Size = new System.Drawing.Size(116, 54);
            this.btn查詢.TabIndex = 87;
            this.btn查詢.Text = "品名查詢";
            this.btn查詢.UseVisualStyleBackColor = false;
            this.btn查詢.Click += new System.EventHandler(this.btn查詢_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp_MOS_test.Properties.Resources.product;
            this.pictureBox1.Location = new System.Drawing.Point(29, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 53);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 93;
            this.pictureBox1.TabStop = false;
            // 
            // products
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(617, 497);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tb查詢結果);
            this.Controls.Add(this.btn清除全部);
            this.Controls.Add(this.btn產品列表);
            this.Controls.Add(this.btn查詢);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn新增);
            this.Controls.Add(this.btn修改);
            this.Controls.Add(this.btn刪除);
            this.Controls.Add(this.lbox品名);
            this.Controls.Add(this.label1);
            this.Name = "products";
            this.Text = "產品管理";
            this.Load += new System.EventHandler(this.products_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb代號;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb品名;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb規格;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb單價;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox lbox品名;
        private System.Windows.Forms.Button btn新增;
        private System.Windows.Forms.Button btn修改;
        private System.Windows.Forms.Button btn刪除;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn產品列表;
        private System.Windows.Forms.Button btn清除全部;
        private System.Windows.Forms.TextBox tb查詢結果;
        private System.Windows.Forms.Button btn查詢;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
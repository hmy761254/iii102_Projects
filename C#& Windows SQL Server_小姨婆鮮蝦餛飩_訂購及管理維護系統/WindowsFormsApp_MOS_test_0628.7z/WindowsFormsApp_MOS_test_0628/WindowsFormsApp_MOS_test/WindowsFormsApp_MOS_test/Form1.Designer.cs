﻿namespace WindowsFormsApp_MOS_test
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmb付款情形 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cmb取貨情形 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPlus = new System.Windows.Forms.Button();
            this.btnMinus = new System.Windows.Forms.Button();
            this.tb數量 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tb規格 = new System.Windows.Forms.TextBox();
            this.tb運費 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb取貨方式 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn確定 = new System.Windows.Forms.Button();
            this.btn取消 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.tb品名 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb單價 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tb小計 = new System.Windows.Forms.TextBox();
            this.cmb顧客姓名 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tb總額 = new System.Windows.Forms.TextBox();
            this.btn結帳 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbox菜單 = new System.Windows.Forms.ListBox();
            this.btn訂單管理 = new System.Windows.Forms.Button();
            this.btn產品管理 = new System.Windows.Forms.Button();
            this.btn會員管理 = new System.Windows.Forms.Button();
            this.dgvUserOrders = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl日期 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.tb顧客代號 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tb產品代號 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tb項次 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tb單號 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserOrders)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CadetBlue;
            this.panel1.Controls.Add(this.cmb付款情形);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.cmb取貨情形);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnPlus);
            this.panel1.Controls.Add(this.btnMinus);
            this.panel1.Controls.Add(this.tb數量);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.tb規格);
            this.panel1.Controls.Add(this.tb運費);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.cmb取貨方式);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btn確定);
            this.panel1.Controls.Add(this.btn取消);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.tb品名);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.tb單價);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.tb小計);
            this.panel1.Location = new System.Drawing.Point(260, 94);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(554, 308);
            this.panel1.TabIndex = 60;
            // 
            // cmb付款情形
            // 
            this.cmb付款情形.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmb付款情形.FormattingEnabled = true;
            this.cmb付款情形.Items.AddRange(new object[] {
            "已付款",
            "未付款"});
            this.cmb付款情形.Location = new System.Drawing.Point(380, 176);
            this.cmb付款情形.Name = "cmb付款情形";
            this.cmb付款情形.Size = new System.Drawing.Size(145, 34);
            this.cmb付款情形.TabIndex = 81;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(278, 173);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 26);
            this.label11.TabIndex = 80;
            this.label11.Text = "付款情形:";
            // 
            // cmb取貨情形
            // 
            this.cmb取貨情形.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmb取貨情形.FormattingEnabled = true;
            this.cmb取貨情形.Items.AddRange(new object[] {
            "已取貨",
            "未取貨"});
            this.cmb取貨情形.Location = new System.Drawing.Point(380, 132);
            this.cmb取貨情形.Name = "cmb取貨情形";
            this.cmb取貨情形.Size = new System.Drawing.Size(145, 34);
            this.cmb取貨情形.TabIndex = 79;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(278, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 26);
            this.label1.TabIndex = 78;
            this.label1.Text = "取貨情形:";
            // 
            // btnPlus
            // 
            this.btnPlus.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnPlus.Location = new System.Drawing.Point(206, 162);
            this.btnPlus.Name = "btnPlus";
            this.btnPlus.Size = new System.Drawing.Size(37, 35);
            this.btnPlus.TabIndex = 77;
            this.btnPlus.Text = "+";
            this.btnPlus.UseVisualStyleBackColor = true;
            this.btnPlus.Click += new System.EventHandler(this.btnPlus_Click);
            // 
            // btnMinus
            // 
            this.btnMinus.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnMinus.Location = new System.Drawing.Point(81, 162);
            this.btnMinus.Name = "btnMinus";
            this.btnMinus.Size = new System.Drawing.Size(37, 35);
            this.btnMinus.TabIndex = 76;
            this.btnMinus.Text = "-";
            this.btnMinus.UseVisualStyleBackColor = true;
            this.btnMinus.Click += new System.EventHandler(this.btnMinus_Click);
            // 
            // tb數量
            // 
            this.tb數量.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb數量.Location = new System.Drawing.Point(124, 162);
            this.tb數量.Name = "tb數量";
            this.tb數量.Size = new System.Drawing.Size(76, 35);
            this.tb數量.TabIndex = 75;
            this.tb數量.TextChanged += new System.EventHandler(this.tb數量_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(16, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 26);
            this.label8.TabIndex = 73;
            this.label8.Text = "規格:";
            // 
            // tb規格
            // 
            this.tb規格.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb規格.Location = new System.Drawing.Point(81, 65);
            this.tb規格.Name = "tb規格";
            this.tb規格.ReadOnly = true;
            this.tb規格.Size = new System.Drawing.Size(162, 35);
            this.tb規格.TabIndex = 74;
            // 
            // tb運費
            // 
            this.tb運費.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb運費.Location = new System.Drawing.Point(380, 62);
            this.tb運費.Name = "tb運費";
            this.tb運費.Size = new System.Drawing.Size(145, 35);
            this.tb運費.TabIndex = 72;
            this.tb運費.TextChanged += new System.EventHandler(this.tb運費_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(320, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 26);
            this.label3.TabIndex = 71;
            this.label3.Text = "運費:";
            // 
            // cmb取貨方式
            // 
            this.cmb取貨方式.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmb取貨方式.FormattingEnabled = true;
            this.cmb取貨方式.Items.AddRange(new object[] {
            "自取",
            "宅配"});
            this.cmb取貨方式.Location = new System.Drawing.Point(380, 18);
            this.cmb取貨方式.Name = "cmb取貨方式";
            this.cmb取貨方式.Size = new System.Drawing.Size(145, 34);
            this.cmb取貨方式.TabIndex = 40;
            this.cmb取貨方式.SelectedIndexChanged += new System.EventHandler(this.cmb取貨方式_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(278, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 26);
            this.label2.TabIndex = 39;
            this.label2.Text = "取貨方式:";
            // 
            // btn確定
            // 
            this.btn確定.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn確定.Location = new System.Drawing.Point(315, 241);
            this.btn確定.Name = "btn確定";
            this.btn確定.Size = new System.Drawing.Size(94, 55);
            this.btn確定.TabIndex = 27;
            this.btn確定.Text = "確定";
            this.btn確定.UseVisualStyleBackColor = true;
            this.btn確定.Click += new System.EventHandler(this.btn確定_Click);
            // 
            // btn取消
            // 
            this.btn取消.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn取消.Location = new System.Drawing.Point(431, 241);
            this.btn取消.Name = "btn取消";
            this.btn取消.Size = new System.Drawing.Size(94, 55);
            this.btn取消.TabIndex = 8;
            this.btn取消.Text = "取消";
            this.btn取消.UseVisualStyleBackColor = true;
            this.btn取消.Click += new System.EventHandler(this.btn取消_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(16, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 26);
            this.label4.TabIndex = 13;
            this.label4.Text = "品名:";
            // 
            // tb品名
            // 
            this.tb品名.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb品名.Location = new System.Drawing.Point(82, 18);
            this.tb品名.Name = "tb品名";
            this.tb品名.ReadOnly = true;
            this.tb品名.Size = new System.Drawing.Size(161, 35);
            this.tb品名.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(16, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 26);
            this.label5.TabIndex = 15;
            this.label5.Text = "單價:";
            // 
            // tb單價
            // 
            this.tb單價.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb單價.Location = new System.Drawing.Point(82, 113);
            this.tb單價.Name = "tb單價";
            this.tb單價.ReadOnly = true;
            this.tb單價.Size = new System.Drawing.Size(161, 35);
            this.tb單價.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(16, 165);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 26);
            this.label6.TabIndex = 17;
            this.label6.Text = "數量:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(16, 223);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 26);
            this.label7.TabIndex = 19;
            this.label7.Text = "小計:";
            // 
            // tb小計
            // 
            this.tb小計.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb小計.Location = new System.Drawing.Point(82, 220);
            this.tb小計.Name = "tb小計";
            this.tb小計.Size = new System.Drawing.Size(161, 35);
            this.tb小計.TabIndex = 20;
            // 
            // cmb顧客姓名
            // 
            this.cmb顧客姓名.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cmb顧客姓名.FormattingEnabled = true;
            this.cmb顧客姓名.Location = new System.Drawing.Point(116, 13);
            this.cmb顧客姓名.Name = "cmb顧客姓名";
            this.cmb顧客姓名.Size = new System.Drawing.Size(166, 34);
            this.cmb顧客姓名.TabIndex = 83;
            this.cmb顧客姓名.SelectedIndexChanged += new System.EventHandler(this.cmb顧客姓名_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(14, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 26);
            this.label12.TabIndex = 82;
            this.label12.Text = "顧客姓名:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(14, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 26);
            this.label9.TabIndex = 23;
            this.label9.Text = "訂單總額:";
            // 
            // tb總額
            // 
            this.tb總額.BackColor = System.Drawing.Color.MediumAquamarine;
            this.tb總額.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb總額.Location = new System.Drawing.Point(121, 40);
            this.tb總額.Name = "tb總額";
            this.tb總額.ReadOnly = true;
            this.tb總額.Size = new System.Drawing.Size(161, 35);
            this.tb總額.TabIndex = 24;
            // 
            // btn結帳
            // 
            this.btn結帳.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn結帳.Location = new System.Drawing.Point(361, 19);
            this.btn結帳.Name = "btn結帳";
            this.btn結帳.Size = new System.Drawing.Size(159, 74);
            this.btn結帳.TabIndex = 50;
            this.btn結帳.Text = "結帳";
            this.btn結帳.UseVisualStyleBackColor = true;
            this.btn結帳.Click += new System.EventHandler(this.btn結帳_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.CadetBlue;
            this.groupBox1.Controls.Add(this.lbox菜單);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(12, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(230, 458);
            this.groupBox1.TabIndex = 70;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "菜單";
            // 
            // lbox菜單
            // 
            this.lbox菜單.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbox菜單.FormattingEnabled = true;
            this.lbox菜單.ItemHeight = 26;
            this.lbox菜單.Location = new System.Drawing.Point(14, 47);
            this.lbox菜單.Name = "lbox菜單";
            this.lbox菜單.Size = new System.Drawing.Size(196, 394);
            this.lbox菜單.TabIndex = 68;
            this.lbox菜單.SelectedIndexChanged += new System.EventHandler(this.lbox菜單_SelectedIndexChanged);
            // 
            // btn訂單管理
            // 
            this.btn訂單管理.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn訂單管理.Location = new System.Drawing.Point(840, 20);
            this.btn訂單管理.Name = "btn訂單管理";
            this.btn訂單管理.Size = new System.Drawing.Size(118, 60);
            this.btn訂單管理.TabIndex = 55;
            this.btn訂單管理.Text = "訂單管理";
            this.btn訂單管理.UseVisualStyleBackColor = true;
            this.btn訂單管理.Click += new System.EventHandler(this.btn訂單管理_Click);
            // 
            // btn產品管理
            // 
            this.btn產品管理.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn產品管理.Location = new System.Drawing.Point(840, 170);
            this.btn產品管理.Name = "btn產品管理";
            this.btn產品管理.Size = new System.Drawing.Size(119, 60);
            this.btn產品管理.TabIndex = 52;
            this.btn產品管理.Text = "產品管理";
            this.btn產品管理.UseVisualStyleBackColor = true;
            this.btn產品管理.Click += new System.EventHandler(this.btn產品管理_Click);
            // 
            // btn會員管理
            // 
            this.btn會員管理.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn會員管理.Location = new System.Drawing.Point(840, 94);
            this.btn會員管理.Name = "btn會員管理";
            this.btn會員管理.Size = new System.Drawing.Size(118, 60);
            this.btn會員管理.TabIndex = 51;
            this.btn會員管理.Text = "顧客維護";
            this.btn會員管理.UseVisualStyleBackColor = true;
            this.btn會員管理.Click += new System.EventHandler(this.btn會員管理_Click);
            // 
            // dgvUserOrders
            // 
            this.dgvUserOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUserOrders.Location = new System.Drawing.Point(21, 48);
            this.dgvUserOrders.Name = "dgvUserOrders";
            this.dgvUserOrders.ReadOnly = true;
            this.dgvUserOrders.RowTemplate.Height = 24;
            this.dgvUserOrders.Size = new System.Drawing.Size(762, 150);
            this.dgvUserOrders.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.CadetBlue;
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.dgvUserOrders);
            this.panel2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel2.Location = new System.Drawing.Point(15, 544);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(799, 218);
            this.panel2.TabIndex = 62;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(8, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 31);
            this.label10.TabIndex = 78;
            this.label10.Text = "訂單明細";
            // 
            // lbl日期
            // 
            this.lbl日期.AutoSize = true;
            this.lbl日期.BackColor = System.Drawing.Color.PowderBlue;
            this.lbl日期.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl日期.Location = new System.Drawing.Point(37, 20);
            this.lbl日期.Name = "lbl日期";
            this.lbl日期.Size = new System.Drawing.Size(184, 31);
            this.lbl日期.TabIndex = 71;
            this.lbl日期.Text = "2018年6月24日";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.tb顧客代號);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.tb產品代號);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.tb項次);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.tb單號);
            this.panel3.Location = new System.Drawing.Point(840, 431);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(146, 322);
            this.panel3.TabIndex = 72;
            this.panel3.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label16.Location = new System.Drawing.Point(3, 241);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 24);
            this.label16.TabIndex = 21;
            this.label16.Text = "客戶代號:";
            // 
            // tb顧客代號
            // 
            this.tb顧客代號.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb顧客代號.Location = new System.Drawing.Point(7, 278);
            this.tb顧客代號.Name = "tb顧客代號";
            this.tb顧客代號.ReadOnly = true;
            this.tb顧客代號.Size = new System.Drawing.Size(114, 33);
            this.tb顧客代號.TabIndex = 22;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(3, 167);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 24);
            this.label15.TabIndex = 19;
            this.label15.Text = "產品代號:";
            // 
            // tb產品代號
            // 
            this.tb產品代號.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb產品代號.Location = new System.Drawing.Point(7, 194);
            this.tb產品代號.Name = "tb產品代號";
            this.tb產品代號.ReadOnly = true;
            this.tb產品代號.Size = new System.Drawing.Size(114, 33);
            this.tb產品代號.TabIndex = 20;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label14.Location = new System.Drawing.Point(3, 104);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 24);
            this.label14.TabIndex = 17;
            this.label14.Text = "項次:";
            // 
            // tb項次
            // 
            this.tb項次.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb項次.Location = new System.Drawing.Point(7, 131);
            this.tb項次.Name = "tb項次";
            this.tb項次.ReadOnly = true;
            this.tb項次.Size = new System.Drawing.Size(104, 33);
            this.tb項次.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(3, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 24);
            this.label13.TabIndex = 15;
            this.label13.Text = "單號:";
            // 
            // tb單號
            // 
            this.tb單號.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tb單號.Location = new System.Drawing.Point(7, 59);
            this.tb單號.Name = "tb單號";
            this.tb單號.ReadOnly = true;
            this.tb單號.Size = new System.Drawing.Size(104, 33);
            this.tb單號.TabIndex = 16;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.CadetBlue;
            this.panel4.Controls.Add(this.btn結帳);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.tb總額);
            this.panel4.Location = new System.Drawing.Point(260, 413);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(554, 110);
            this.panel4.TabIndex = 73;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.CadetBlue;
            this.panel5.Controls.Add(this.cmb顧客姓名);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Location = new System.Drawing.Point(260, 21);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(554, 62);
            this.panel5.TabIndex = 74;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(979, 779);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lbl日期);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn訂單管理);
            this.Controls.Add(this.btn產品管理);
            this.Controls.Add(this.btn會員管理);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "小姨婆鮮蝦餛飩";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserOrders)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cmb取貨方式;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn確定;
        private System.Windows.Forms.TextBox tb總額;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb小計;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb單價;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb品名;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn取消;
        private System.Windows.Forms.Button btn訂單管理;
        private System.Windows.Forms.Button btn產品管理;
        private System.Windows.Forms.Button btn會員管理;
        private System.Windows.Forms.Button btn結帳;
        private System.Windows.Forms.ListBox lbox菜單;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tb運費;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb規格;
        private System.Windows.Forms.DataGridView dgvUserOrders;
        private System.Windows.Forms.Button btnPlus;
        private System.Windows.Forms.Button btnMinus;
        private System.Windows.Forms.TextBox tb數量;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmb付款情形;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmb取貨情形;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmb顧客姓名;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl日期;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tb顧客代號;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tb產品代號;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tb項次;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tb單號;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
    }
}

